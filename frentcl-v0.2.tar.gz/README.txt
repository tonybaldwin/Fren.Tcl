Fren.Tcl

a tcl/tk Friendica posting client
by Tony Baldwin | http://tonybaldwin.me

Version 0.2.1

fren.tcl will post to your friendica profile, 
and allows cross-posting to tumblr, posterous,
wordpress, livejournal, dreamwidth, twitter, facebook,
and statusnet IF your friendica admin has enable the plugins
for such crossposting connections, and, of course, you have
properly set the plugins up for yourself in your settings
on friendica.

INSTALLATION
For gnu/linux systems: Run the install.sh script.
Everybody else, you'll have to figure it out.
I only use gnu/linux.

There is information on my wiki at tonybaldwin.me/hax on how to run tcl
programs on windows, but, I recommend running this on gnu/linux.

Thanks for your support.

<3 <3 <3
x0x0x0x0x

./tony
https://free-haven.org/profile/tony
http://tonybaldwin.me

QUICKNOTE:
New version has option to force SSL for friendica posting (haven done it for statusnet, yet).
If you check the box, MAKE SURE YOU USE https:// (not http://) in your friendica url.
If you do NOT check the box, use http://
