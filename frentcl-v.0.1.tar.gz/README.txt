Fren.Tcl

a tcl/tk Friendika posting client
by Tony Baldwin | http://www.baldwinsoftware.com

This read me has almost nothing of value to tell you.
I hacked up this little thingy in a couple hours time.

It needs more work.

This is like version 0.1, or something.
Like an Alpha release.
I should seek funding on kickstarter and tease people with invites.
:P Diaspora*
HAHAHAHA!!!

Anyway, if anyone wants to hack on it, co0l.
Or use it, even.

I will probably get the cross-posting working correctly shortly,
because, well, it isn't right now, but I do have a handy bash script for
that stuff, which is also in here.

That would be frendi.sh

The tcl script, fren.tcl, will upvar the frentcl.conf file to set
variables, like your username:password and the server on which
you are friendika-ing, your preferred browser, etc.

You can also post to a status.net installation with this thingy,
but I do not have the cross-posting part working correctly to 
post to friendika and status.net simultaneously, yet, in the tcl script.
It works in the bash script.

If you haven't the technological wherewithall to make either of these work
for yourself, you should probably just post from the web interface
for now, and wait until I (or some kind soul) rounds out this code.

Thanks for your support.

<3 <3 <4
x0x0x0x0x

./tony
http://friendika.dsn-test.com/profile/tonybaldwin
